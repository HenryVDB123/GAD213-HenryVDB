using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using TMPro;
public class Movement : MonoBehaviour
{

    public int speed;
    public int Rotatespeed;
    public int Reversespeed;
    public Vector3 rotations;
    [SerializeField] private float timer;
    public TextMeshProUGUI TimeIndicator;
    public int SpeedLimit;
    public bool InTime;

    // Start is called before the first frame update
    void Start()
    {
        speed = 0;
        SpeedLimit = 75;
        Rotatespeed = 100;
        Reversespeed = 25;
        InTime = true;
    }
    // Update is called once per frame
    void Update()
    {

        if (speed > SpeedLimit)
        {
            speed = 75;
        }

        transform.position += transform.forward * speed * Time.deltaTime;
        if (Input.GetKey(KeyCode.W))
        {
            if (speed != SpeedLimit)
            {
                speed = speed + 1;
            }
        }
        else if (!Input.GetKey(KeyCode.W))
        {
            if (speed != 0)
            {
                speed = speed - 1;
            }
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.position += transform.forward * -1 * Reversespeed * Time.deltaTime;
            
        }
        if (Input.GetKey(KeyCode.LeftShift))
        {
            Rotatespeed = 175;
            if (speed != 0)
            {
                speed = 25;
            }
        }
        else
        {
            Rotatespeed = 100;
        }

        {
            TimeIndicator.text = timer.ToString();

            timer += Time.deltaTime; 

            if (timer > 0.4)
            {
                if (timer < 1)
                {
                    if (InTime == true)
                    {
                        if (Input.GetKeyDown(KeyCode.Space))
                        {
                            SpeedLimit = 150;
                            speed = 150;
                        }
                    }
                    
                }

                else if (timer > 1)
                {
                    timer = 0;
                    SpeedLimit = 75;
                    InTime = true;
                }
            }

            if (timer !< 0.4)
                {
                    if (Input.GetKeyDown(KeyCode.Space))
                    {
                        InTime = false;
                    }
                }

        }
    }

    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.D))
        {
            rotations = Vector3.up;
        }

        else if (Input.GetKey(KeyCode.A))
        {
            rotations = Vector3.down;
        }
       
        else
        {
            rotations = Vector3.zero;
        }

        transform.Rotate(rotations * Rotatespeed * Time.deltaTime);
    }
}
